import './App.css'
import Footer from './componentes/Footer'
import Header from './componentes/Header'

function App() {

  return (
    <>
      <Header />
      <section className='container'>
        <div>

        </div>

      </section>
      <Footer />
      <section className='final'>
        <div className='final2'>
          <p>Faça parte da revolução na organização de roupas e torne</p> <p>seu processo de seleção de looks mais fácil, eficiente e divertido com a GoDress. </p> <p>Cadastre-se agora e comece a transformar sua maneira de se vestir!</p>
        </div>

      </section>

    </>
  )
}

export default App
