import styles from './Footer.module.css'


function Footer() {
    return(
            <footer className={styles.footer}>
                <h1>Experimente Agora!</h1>
            </footer>
    )
}


export default Footer
