import Styles from './Header.module.css'

function Header() {
  return (
    <header className={Styles.header}>
      <span>GoDress</span>
      <nav>
        <a href="">Quem somos?</a>
        <a href="">Sobre</a>
        <a href="">Nossa proposta</a>
      </nav>
    </header>

  )

}

export default Header